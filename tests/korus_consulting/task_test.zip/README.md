#start
-in unix system
-start venv
-activate venv
-in win system
-start venv
-activate.bat venv
run main.py

