from .data_base_function import calculator, departments, transactions
